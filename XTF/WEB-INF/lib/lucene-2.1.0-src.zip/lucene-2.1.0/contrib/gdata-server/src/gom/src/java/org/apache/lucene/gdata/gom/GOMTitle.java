/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.gdata.gom;

/**
 * 
 * The "atom:title" element is a Text construct that conveys a human-readable
 * title for an entry or feed.
 * 
 * <pre>
 *  atomTitle = element atom:title { atomTextConstruct }
 * </pre>
 * 
 * @author Simon Willnauer
 * 
 */
public interface GOMTitle extends GOMElement {

	/**
	 * Atom local name for the xml element
	 */
	public static final String LOCALNAME = "title";

	/**
	 * @return - the content type attribute value as a {@link ContentType}
	 * @see ContentType
	 */
	public abstract ContentType getContentType();
}
