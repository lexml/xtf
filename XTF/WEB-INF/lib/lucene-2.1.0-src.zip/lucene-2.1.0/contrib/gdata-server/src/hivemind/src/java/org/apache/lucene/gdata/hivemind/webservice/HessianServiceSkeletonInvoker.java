/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.gdata.hivemind.webservice;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Internal invoker interface to support more than one version of the protocol. <b>Currently only Version 3.0.20 is supported.<b>
 * 
 * @author Simon Willnauer
 * 
 */
public interface HessianServiceSkeletonInvoker {

    /**
     * @param arg0 - httpServletRequest to access the input stream for processing
     * @param arg1 - httpServletResponse to access the output stream for processing
     * @throws IOException - if reading or writeing causes an IOException
     * @throws Throwable - if the Hessian Impl. causes an error
     */
    public abstract void invoke(HttpServletRequest arg0, HttpServletResponse arg1)
            throws IOException, Throwable;

}
